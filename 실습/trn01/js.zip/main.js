$(function () {
    $('.top_baner i').on('click', function () {
        $('.top_baner').slideUp();
    });

    $('.main_slider').slick({
        arrows: false,
        autoplay: true,
        autoplaySpeed: 1000,
        pauseOnHover: false,
    })
})


